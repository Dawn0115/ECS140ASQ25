package main

import (
	"fmt"
	"hw1/expr"
)

func main() {
	var result float64

	result = 42.0
	fmt.Printf("%d\n", result)
}
