reachable(StartState, FinalState, Input) :-
    %% remove fail and add body/other cases for this predicate
    fail.
